﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace Semprini.Kevin._4i.rubricaWebDb.Models
{
    public class Persona
    {
        [Key] public int Id { get; set; }
        private int? _Idnumero;
        private string? _nome;
        private string? _cognome;

        public string? Nome { get; set; }
        public string? Cognome { get; set; }
        public int? IdNumero
        {
            get
            {
                return _Idnumero;
            }

            set
            {
                if (value < 0 || value > 100)
                {
                    throw new ArgumentOutOfRangeException();
                }
                else
                {
                    _Idnumero = value;
                }
            }
        }

        public Persona() { }

        public Persona(string riga)
        {
            // ".split()" crea una vettore di elemnti stringa
            string[] campi = riga.Split(';');
            int PK = 0;

            int.TryParse(campi[0], out PK);
            this.IdNumero = PK;
            string PKstr = PK.ToString();
            if (PKstr == "PK") { this.IdNumero = 1; }

            this.Nome = campi[1];
            this.Cognome = campi[2];
            //tryParse serve a convertire il valore dato come primo paramentro in un valore di tipo "int"
            //in questoc caso, e metterlo nella variabile PK che è di tipo int, è sempre stringa > var
            //in pratica lui controlla la stringa e prende  il valore richiesto dalla variabile messa
        }
    }

    public class Persone : List<Persona>
    {
        public Persone(string nomeFile)
        {
            StreamReader fin = new StreamReader(nomeFile);
            fin.ReadLine();

            while (!fin.EndOfStream)
            {
                string riga = fin.ReadLine();
                Persona c = new Persona(riga);
                Add(c);
            }

            fin.Close();
        }
    }
}
