﻿using Microsoft.EntityFrameworkCore;


//questo è il file  database
namespace Semprini.Kevin._4i.rubricaWebDb.Models
{
    //serve a contenere taante classi che verranno usate per la rubrica (perona,contatti, ecc....) come tabelle
    public class dbContext : DbContext
    {
        private readonly DbContextOptions? _options;
        public dbContext() { }

        protected override void OnConfiguring(DbContextOptionsBuilder options)
                => options.UseSqlite("Data Source=DbRubrica.db"); //la stringa sarà il nome del database

        public DbSet<Persona> Persone { get; set; }
    }
}
