using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Semprini.Kevin._4i.rubricaWebDb.Models;

namespace Semprini.Kevin._4i.rubricaWebDb.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    [HttpGet]
    public IActionResult Index()
    {
        dbContext db = new dbContext();


        // Se non ci sono record, ne aggiunge uno...
        if (db.Persone.Count() == 0)
        {
            db.Persone.Add(new Persona { Nome = "Maurizio", Cognome ="Conti" });
            db.Persone.Add(new Persona { Nome = "Maurizio", Cognome = "Conti2" });
            db.Persone.Add(new Persona { Nome = "Maurizio", Cognome = "Conti3" });

            db.SaveChanges();
        }


        // Passa il db alla view
        return View(db);
    }


    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
